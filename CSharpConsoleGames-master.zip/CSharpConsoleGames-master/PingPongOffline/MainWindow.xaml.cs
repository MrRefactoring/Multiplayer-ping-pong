﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;

namespace PingPongOffline
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private int frameRate = 60;

        private Thread gameThread;
        private bool runnable = false;

        public MainWindow()
        {
            InitializeComponent();
            gameThread = new Thread(gameLoop);
        }

        private void start()
        {
            if (!runnable)
            {
                gameThread.Start();
                runnable = true;
            }
        }

        private void stop()
        {
            if (runnable)
            {
                runnable = false;
                gameThread.Abort();
            }
        }

        private void gameLoop()
        {
            long lastUpdate = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;
            while (true)
            {
                if (DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond - lastUpdate >= 1000 / frameRate)
                {

                } else
                {
                    continue;
                }
            }
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Threading;

namespace PingPongNew.PlayGrounds
{
    public partial class SinglePlayer : Window
    {

        private double width, heigth;

        private Thread thread;
        private bool running = false;

        private double ballSpeed = new Random().Next(-3, 3) * 5;
        private double ballVertSpeed = new Random().Next(-3, 3) * 5;

        private string key = null;
        private double step = 10d;
        private double enemy_step = 5d;

        public SinglePlayer()
        {
            InitializeComponent();
            width = this.Width;
            heigth = this.Height;
            gameLoop();
            start();
            
        }

        private void gameLoop()
        {

            setStartPosition();
            thread = new Thread(() =>
            {
                long lastUpdate = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;
                while (true)
                {
                    if (DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond - lastUpdate > 1000 / 20)
                    {
                        Dispatcher.Invoke(new Action(() => {
                            ballMove();
                            leftPadMove();
                            rightPadMove();
                        }));
                        lastUpdate = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;
                    }
                }
            });
        }

        private void ballMove()
        {
            ball.Margin = new Thickness(ball.Margin.Left + ballSpeed,
                ball.Margin.Top + ballVertSpeed, 0, 0);
            if (topWallCollision() || bottomWallCollision())  // Если ударяемся об верх
            {
                ballVertSpeed = -ballVertSpeed;
            }
            if (leftPadCollision() || rightPadCollision())
            {
                ballSpeed = -ballSpeed;
                //ballVertSpeed = -ballVertSpeed;
            }
            else if (leftWallCollision())
            {
                // TODO + to right player points
                setStartPosition();
            } else if (rightWallCollision())
            {
                // TODO + to left player points
                setStartPosition();
            }
        }

        private void leftPadMove()
        {
            if (key == "up" && leftPad.Margin.Top > 0)
            {
                leftPad.Margin = new Thickness(leftPad.Margin.Left, leftPad.Margin.Top - step, 0, 0);
            } else if (key == "down" && leftPad.Margin.Top + leftPad.Height * 1.4 < heigth)
            {
                leftPad.Margin = new Thickness(leftPad.Margin.Left, leftPad.Margin.Top + step, 0, 0);
            }
        }

        private void rightPadMove()
        {
            if (ball.Margin.Top < rightPad.Margin.Top + rightPad.Height &&
                ball.Margin.Top < rightPad.Margin.Top)
            {
                rightPad.Margin = new Thickness(rightPad.Margin.Left, rightPad.Margin.Top - enemy_step, 0, 0);
            } else if (ball.Margin.Top > rightPad.Margin.Top + rightPad.Height &&
                ball.Margin.Top > rightPad.Margin.Top)
            {
                rightPad.Margin = new Thickness(rightPad.Margin.Left, rightPad.Margin.Top + enemy_step, 0, 0);
            }
        }

        private void start()
        {
            if (!running)
            {
                thread.Start();
                running = true;
            }
        }

        private void stop()
        {
            if (running)
            {
                thread.Abort();
                running = false;
            }
        }

        private void setStartPosition()
        {
            ball.Margin = new Thickness(width / 2 - ball.Width / 2, heigth / 2 - ball.Height / 2 - 15, 0, 0);
            leftPad.Margin = new Thickness(leftPad.Margin.Left, heigth / 2 - leftPad.Height / 2 - 15, 0, 0);
            rightPad.Margin = new Thickness(rightPad.Margin.Left,
                heigth / 2 - rightPad.Height / 2 - 15, 0, 10);
        }

        private bool leftWallCollision()
        {
            return ball.Margin.Left <= 0;
        }

        private bool topWallCollision()
        {
            return ball.Margin.Top <= 0;
        }

        private void stop(object sender, System.ComponentModel.CancelEventArgs e)
        {
            stop();
        }

        private bool rightWallCollision()
        {
            if (ball.Margin.Left + ball.Width * 2 >= width)
            {
                return true;
            }
            return false;
        }

        private bool bottomWallCollision()
        {
            if (ball.Margin.Top + ball.Height * 3 >= heigth)
            {
                return true;
            }
            return false;
        }

        private bool leftPadCollision()
        {
            if (ball.Margin.Top < leftPad.Margin.Top + leftPad.Height &&
               ball.Margin.Top > leftPad.Margin.Top &&
               ball.Margin.Left <= leftPad.Margin.Left + leftPad.Width)
            {
                return true;
            }
            return false;
        }

        private void WinKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Up)
            {
                key = "up";
            } else if (e.Key == Key.Down)
            {
                key = "down";
            }
        }

        private void WinKeyUp(object sender, KeyEventArgs e)
        {
            key = null;
        }

        private bool rightPadCollision()
        {
            if (ball.Margin.Top < leftPad.Margin.Top + leftPad.Height &&
               ball.Margin.Top > leftPad.Margin.Top &&
               ball.Margin.Left + ball.Width * 2 >= rightPad.Margin.Left)
            {
                return true;
            }
            return false;
        }

    }
}

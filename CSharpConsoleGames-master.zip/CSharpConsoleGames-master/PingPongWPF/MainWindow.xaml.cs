﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;

namespace PingPongWPF
{
    public partial class MainWindow : Window
    {

        private double speed = 2d;
        private double verticalSpeed = 1d;

        private double widhth, heigth;

        public MainWindow()
        {
            InitializeComponent();
            widhth = this.Width;
            heigth = this.Height;
            initPos();
            new Thread(() => {
                long lastUpdate = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;
                while (true)
                {
                    if (DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond - lastUpdate > 1000 / 20)
                    {
                        Dispatcher.Invoke(new Action(ballManager));
                        lastUpdate = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;
                    } else
                    {
                        continue;
                    }
                }
            }).Start();
        }

        private void ballManager()
        {
            Console.WriteLine("{0}", padCollision() && leftCollision());
            ball.Margin = new Thickness(ball.Margin.Left - 1 * speed, ball.Margin.Top, 0, 0);
        }

       /* private void ballMove()
        {
            if (ball.Margin.Top <= 0)  // Если ударился о верхнюю площадку
            {
                verticalSpeed = - new Random().NextDouble() * 5;  // Новая вертикальная скорость
            }
        }*/

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Down)
            {
                if (leftPad.Margin.Top < heigth - leftPad.Height - leftPad.Height / 2 + 10)
                {
                    leftPad.Margin = new Thickness(leftPad.Margin.Left, leftPad.Margin.Top + 10, 0, 0);
                }
            } else if (e.Key == Key.Up)
            {
                if (leftPad.Margin.Top > 0)
                {
                    leftPad.Margin = new Thickness(leftPad.Margin.Left, leftPad.Margin.Top - 10, 0, 0);
                }
            }
        }

        private void initPos()
        {
            ball.Margin = new Thickness(widhth / 2 - ball.Width / 2, heigth / 2 - ball.Height / 2 - 15, 0, 0);
            leftPad.Margin = new Thickness(leftPad.Margin.Left, heigth / 2 - leftPad.Height / 2 - 15, 0, 0);
            rightPad.Margin = new Thickness(rightPad.Margin.Left - 10, heigth / 2 - rightPad.Height / 2 - 15, 0, 0);
        }

        private bool padCollision()
        {
            if (ball.Margin.Top < leftPad.Margin.Top + leftPad.Height &&
                ball.Margin.Top > leftPad.Margin.Top)
            {
                return true;
            }
            return false;
        }

        private bool leftCollision()
        {
            if (ball.Margin.Left <= leftPad.Margin.Left + leftPad.Width)
            {
                return true;
            }
            return false;
        }

    }
}

﻿namespace Lib.Interfaces
{
    interface ILogic
    {

        void setStartPosition();
        void move(string key);

    }
}
